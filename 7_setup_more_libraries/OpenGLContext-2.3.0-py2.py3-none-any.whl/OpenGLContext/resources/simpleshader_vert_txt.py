# -*- coding: ISO-8859-1 -*-
"""Resource simpleshader_vert_txt (from file simpleshader.vert.txt)"""
# written by resourcepackage: (1, 0, 1)
source = 'simpleshader.vert.txt'
package = 'OpenGLContext.resources'

import zlib
data = zlib.decompress((b'x\xda+\xcb\xcfLQ\xc8M\xcc\xcc\xd3\xd0T\xa8\xe6\xe2L\xcf\x89\x0f\xc8/\xce,\xc9\xcc\xcfS\xb0U\x00\xf2|\xf3SRs\xc22S\xcb\x03\x8a\xf2\xb3R\x93A\x12\xbe\x89%E\x99\x15\nZ \xe9'
+b'\xb0\xd4\xa2\x92\xd4\nk\xaeZ.\x00\xb2f\x19\xb1'))
### end

# -*- coding: ISO-8859-1 -*-
"""Resource simpleshader_frag_txt (from file simpleshader.frag.txt)"""
# written by resourcepackage: (1, 0, 1)
source = 'simpleshader.frag.txt'
package = 'OpenGLContext.resources'

import zlib
data = zlib.decompress((b'x\xda+\xcb\xcfLQ\xc8M\xcc\xcc\xd3\xd0T\xa8\xe6\xe2L\xcf\x89w+JLw\xce\xcf\xc9/R\xb0U(KM6\xd1P0\xd0Q0\xd4\x01\x93\n\x9a\xd6\\\xb5\\\x00\xa7\xeb\x0e\x1a'))
### end
